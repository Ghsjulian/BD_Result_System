<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header(
  "Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
);
/*===================================*/
require_once '../database/__DB__.php';
$message = "";
$status = "";
$__DB__ = new __database__();
$url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$requestMethod = $_SERVER["REQUEST_METHOD"];

if ($_GET['std_id']) {
  $student_id = $_GET['std_id'];
  $sql = "SELECT * FROM students WHERE student_id='$student_id'";
  $select = $__DB__->SelectSingle($sql);
  if ($select) {
   $rool = $select["rool"];
   $student = "DELETE FROM students WHERE student_id='$student_id'";
   $sub = "DELETE FROM subjects WHERE student_id='$rool'";
   $sheet = "DELETE FROM marksheet WHERE roll='$rool'";
   if($__DB__->__INSERT__($student)){
       if($__DB__->__INSERT__($sheet)){
       if($__DB__->__INSERT__($sub)){
         header("location:http://goventryofficialbdresult.ezyro.com/Admin");
   }
   }
   }
  }
}

?>
