<?php
if ($_POST['group']) {
  include('db/conn.php');
  //require_once './db/__DB__.php';
  //$__DB__ = new __database__();
  $err = "";
  $student_name = trim($_POST['student_name']);
  $group = $_POST['group'];
  $roll = trim($_POST['roll_number']);
  $ein_number = trim($_POST['ein_number']);
  $optional_sub = trim($_POST['optional_sub']);
  $religion = trim($_POST['religion']);
  $registration = trim($_POST['reg_number']);
  $password = trim($_POST['password']);
  $enc_password = sha1($password);
  /*
  *
  * MAKING SQL QUERY
  *
  */
  /*
$sql = "INSERT INTO `students`(`student_name`,`rool`,`registration`,`password`,`group`,`optional_subject`,`religion`,`ein`)VALUES('$student_name','$roll','$registration','$enc_password','$group','$optional_sub','$religion','$ein_number')"; */
  $sql = "INSERT INTO `students`(
    `student_name`,
    `rool`,
    `registration`,
    `password`,
    `group`,
    `optional_subject`,
    `religion`,
    `marksheet`,
    `ein`
)
VALUES(
  '$student_name',
  '$roll',
  '$registration',
  '$enc_password',
  '$group',
  '$optional_sub',
  '$religion',
  'NO',
  '$ein_number'
  )";
  /*
$sql = "INSERT INTO `students`(
    `student_name`,
    `rool`,
    `registration`,
    `password`,
    `group`,
    `optional_subject`,
    `religion`,
    `marksheet`,
    `ein`
)
VALUES(
    '[value-2]',
    '[value-3]',
    '[value-4]',
    '[value-5]',
    '[value-6]',
    '[value-7]',
    '[value-8]',
    '[value-9]',
    '[value-10]'
)";
*/

  $query = mysqli_query($conn, $sql);
  if ($query) {
    echo "Inserted";
  } else {
    echo "Failed";
  }


} else {
  echo "Post Method Allowed ";
}

?>