function ghs__(tag) {
  return document.querySelector(tag);
}

ghs__("#add-marksheet").onclick = (e) => {
  var group = ghs__("#group").textContent;
  getAllvalues(group);
};

function getAllvalues(check) {
  var formData = new FormData();
  var group = ghs__("#group").textContent;
  var board = ghs__("#board").value;
  var father = ghs__("#father").value;
  var mother = ghs__("#mother").value;
  var type = ghs__("#type").value;

  var gpa = ghs__("#gpa").value;
  var name = ghs__("#name").textContent;
  var roll = ghs__("#roll").textContent;
  var dob = ghs__("#dob").value;
  var select = ghs__("#select_bank");
  var Selectvalue = select.value;
  var exam_name = select.options[select.selectedIndex].text;
  var year = ghs__("#year").value;
  var ID = ghs__("#hidden-id").value;
  var institute = ghs__("#institute").value;
  var result = ghs__("#result").value;
  formData.append("board", board);
  formData.append("ID", ID);
  formData.append("father", father);
  formData.append("mother", mother);
  formData.append("type", type);
  formData.append("result", result);
  formData.append("roll", roll);
  formData.append("group", group);
  formData.append("gpa", gpa);
  formData.append("name", name);
  formData.append("institute", institute);
  formData.append("birth", dob);
  formData.append("year", year);
  formData.append("exam_name", exam_name);
  var bangla = ghs__("#bangla").value;
  var english = ghs__("#english").value;
  var ict = ghs__("#ict").value;
  var math = ghs__("#math").value;
  var hire_math = ghs__("#hire_math").value;
  var agriculture = ghs__("#agriculture").value;
  var phisical = ghs__("#phisical").value;
  var carrier = ghs__("#carrier").value;
  var history = ghs__("#bangladesh_history").value;
  var economic = ghs__("#economics").value;
  var geography = ghs__("#geography").value;
  var science = ghs__("#science").value;
  var bangladesh_history = ghs__("#global_study").value;
  var physics = ghs__("#physics").value;
  var chemistry = ghs__("#chemistry").value;
  var biology = ghs__("#biology").value;
  formData.append("physics", physics);
  formData.append("chemistry", chemistry);
  formData.append("biology", biology);
  formData.append("global_study", bangladesh_history);
  var bd_history = ghs__("#bangladesh_history").value;
  var finnance = ghs__("#finnance").value;
  var business = ghs__("#business").value;
  var hindu = ghs__("#hindu").value;
  var islam = ghs__("#islam").value;
  var christian = ghs__("#christian").value;
  var accounting = ghs__("#accounting").value;
  //var science = ghs__("#science").value;
  var cm_geography = ghs__("#geography_world").value;

  /*   APPENDING ALL VALUES  */
  formData.append("history", bd_history);
  formData.append("hindu", hindu);
  formData.append("islam", islam);
  formData.append("christian", christian);
  formData.append("business", business);
  formData.append("cm_geography", cm_geography);
  //formData.append("cm_science", cm_science);
  formData.append("accounting", accounting);
  formData.append("finnance", finnance);
  formData.append("history", history);
  formData.append("economic", economic);
  formData.append("geography", geography);
  formData.append("science", science);
  formData.append("bangla", bangla);
  formData.append("english", english);
  formData.append("math", math);
  formData.append("hire_math", hire_math);
  formData.append("ict", ict);
  formData.append("agriculture", agriculture);
  formData.append("phisical", phisical);
  formData.append("carrier", carrier);
  /*    SHEET VALUES   */

  /*    STUDENTS   INFORMATION**/

  //console.log("It's Science")
  /*
   *
   *
   *  HERE I'LL USE AJAX
   *
   *
   */
  fetch("http://goventryofficialbdresult.ezyro.com/API/server/functions/sheet.php", {
    method: "POST",
    body: formData,
  })
    .then((res) => {
      return res.text();
    })
    .then((data) => {
        if (data === "Inserted") {
        window.location.href = "index.php";
      }
      
    });
}

/*
window.onload = () => {
  var std_id = ghs__("#hidden-id").value;
  Fetchstudent(std_id);
};
*/
