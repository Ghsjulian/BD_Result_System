## BD ONLINE RESULTS SYSTEM
# Developer And Desginer Ghs Julian

### Admin Login
```
Email : admin@gmail.com
Password : Adminghs
```

### Student Login 

```
EIN           : 8005
ROLL          : 117790
REGISTRATION  : 14142392
PASSWORD      : 123456
```