# PHP REST API

###### This is the programm which i made to learn php rest api and how does it work . Okay it's my first programm , here i wrote some code that how can i use an api . How to connect with Application . PHP API is learn to easy . I love to work with API because i don't like to repeat myself (DRY) . 

## Example : 
###### I made some example to learn . Okay after learning this API i will make awsome Application . When I will make e commerce websites . and then i will make social media .