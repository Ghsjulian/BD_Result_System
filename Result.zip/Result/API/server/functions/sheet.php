<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header(
  "Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
);
/*===================================*/
require_once "../database/__DB__.php";
$message = "";
$status = "";
$__DB__ = new __database__();
$url = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$requestMethod = $_SERVER["REQUEST_METHOD"];

if ($requestMethod == "POST") {
  $group = $_POST["group"];
  $board = $_POST["board"];
  $father = $_POST["father"];
  $mother = $_POST["mother"];
  $type = $_POST["type"];
  $gpa = $_POST["gpa"];
  $name = trim($_POST["name"]);
  $roll = $_POST["roll"];
  $dob = $_POST["birth"];
  $exam_name = $_POST["exam_name"];
  $year = $_POST["year"];
  $institute = $_POST["institute"];
  $result = $_POST["result"];
  /*    SHEET VALUES   */
  $bangla = $_POST["bangla"];
  $english = $_POST["english"];
  $bangladesh_history = $_POST["global_study"];
  $math = $_POST["math"];
  $ict = $_POST["ict"];
  $ID = $_POST["ID"];
  $physics = $_POST["physics"];
  $chemistry = $_POST["chemistry"];
  $biology = $_POST["biology"];
  $agriculture = $_POST["agriculture"];
  $carrier = $_POST["carrier"];
  $hindu = $_POST["hindu"];
  $islam = $_POST["islam"];
  $christian = $_POST["christian"];
  $phisical = $_POST["phisical"];
  $carrier = $_POST["carrier"];
  $finnance = $_POST["finnance"];
  $economic = $_POST["economic"];
  $business = $_POST["business"];
  $geography = $_POST["geography"];
  $geography_world = $_POST["geography_world"];
  $science = $_POST["science"];
  $physical = $_POST["phisical"];
  $accounting = $_POST["accounting"];
  $history = $_POST["history"];
  $ok = "YES";
  /*   PREPARED FOR SENDING INTO THE SERVER*/
  $sql = "INSERT INTO `subjects`(`student_id`,`student_name`,`bangla`,`english`,`math`,`ict`,`global_study`,`biology`,`chemistry`,`physics`,`hindu_edu`,`islam_edu`,`christian_edu`,`history`,`agriculture`,`economics`,`geography`,`science`,`accounting`,`finnance`,`geography_world`,`business`,`carrier_edu`,`physical_edu`)VALUES('$roll','$name','$bangla','$english','$math','$ict','$bangladesh_history','$biology','$chemistry','$physics','$hindu','$islam','$christian','$history','$agriculture','$economic','$geography','$science','$accounting','$finnance','$geography_world','$business','$carrier','$physical')";
  /*  ADDED THE STUDENTS INFO */
  $info = "INSERT INTO `marksheet`(`student_name`,`roll`,`group`,`year`,`result`,`birth`,`gpa`,`exam_name`,`institute`,`father`,`mother`,`board`)VALUES('$name','$roll','$group','$year','$result','$dob','$gpa','$exam_name','$institute','$father','$mother','$board')";
  $query = $__DB__->__INSERT__($sql);
  if ($query) {
    if ($__DB__->__INSERT__($info)) {
      $update = "UPDATE `students` SET `marksheet`='YES' WHERE `student_id`='$ID'";
      if ($__DB__->__INSERT__($update)) {
        echo "Inserted";
      } else {
        echo "Updated Failed";
      }
    } else {
      echo "Info Failed";
    }
  }
  /*
   *
   *
   *
   *
   *
   */
}
?>
