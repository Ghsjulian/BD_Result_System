<?php
  $__host__ = "85.10.205.173:3306";
  $__user__ = "ghsjulian";
  $__password__ = "ghs_&#80;";
  $__db__ = "relaxtea";
  
$conn = mysqli_connect($__host__, $__user__, $__password__,
      $__db__);
    if (!$conn) {
      return false;
    } 
?>