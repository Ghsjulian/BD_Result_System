<?php
session_start();
$session = $_SESSION['admin'];
if (isset($_POST['student_name'])) {
  require_once './db/__DB__.php';
  $__DB__ = new __database__();
  $err = "";
  $student_name = $_POST['student_name'];
  $group = $_POST['group'];
  $roll = $_POST['roll_number'];
  $ein_number = $_POST['ein_number'];
  $optional_sub = $_POST['optional_sub'];
  $religion = $_POST['religion'];
  $registration = $_POST['reg_number'];
  $password = $_POST['password'];
  $enc_password = sha1($password);
  /*
  *
  * MAKING SQL QUERY
  *
  */
  $select = "SELECT student_name,rool FROM students WHERE student_name='$student_name' AND rool='$roll'";
  if ($__DB__->__LOGIN__($select)) {
    $err = "This Student Already Exist !";
    exit();
  } else {
    /* $sql = "INSERT INTO `students`(`student_name`, `rool`, `registration`, `password`,`group`) VALUES ('$student_name','$roll','$registration','$enc_password','$group')";*/
    $sql = "INSERT INTO `students`(`student_name`, `rool`, `registration`, `password`, `group`, `optional_subject`, `religion`,`ein`)VALUES('$student_name','$roll','$registration','$enc_password','$group','$optional_sub','$religion','$ein_number')";
    $query = $__DB__->__INSERT__($sql);
    if ($query) {
      header("location:index.php");
    }
  }
}





if (isset($session['user_role'])) {
  include_once('header.php');
  ?>
  <body>
    <div class="hero">
      <div class="section">
        <div class="contact">
          <h2>Add A New Student</h2>
          <div class="contact-form">
            <div id="message">
              <?php echo $err ?>
            </div>
            <form id="application_form" method="POST">
              <select name="group" id="select_bank">
                <option>Chose A Group</option>
                <option value="Science">Science</option>
                <option value="Humanity">Humanity</option>
                <option value="Commerce">Commerce</option>
                <option value="Others">Others</option>
              </select>
              <input
              type="text"
              placeholder="Enter Student Full Name"
              id="student_name"
              name="student_name"
              />
            <input
            type="number"
            placeholder="Enter Roll Number"
            id="roll_number"
            name="roll_number"
            />
          <input
          type="number"
          placeholder="Enter EIN Number"
          id="ein_number"
          name="ein_number"
          />
        <input
        type="number"
        placeholder="Enter Registration Number"
        id="reg_number"
        name="reg_number"
        />
      <input
      type="text"
      placeholder="Enter Student Religion"
      id="religion"
      name="religion"
      />
    <input
    type="text"
    placeholder="Enter Optional Subject"
    id="optional_sub"
    name="optional_sub"
    />
  <input
  type="password"
  placeholder="Set Student Password"
  id="password"
  name="password"
  />
<button
  type="button"
  id="btn"
  name="contact-btn" onclick="Addstudent()"
  >
  Add Student
</button>
</form>
</div>
</div>
</div>
</div>
<script>

function ghs__(tag) {
return document.querySelector(tag);
}
function __ghs(tag) {
return document.querySelector(tag);
}
function OpenMenu() {
var menu = ghs__("#mobile-menu").getAttribute("data");
if (menu == "1") {
ghs__("#menu").style.display = "none";
//ghs__("#menu").classList.add("mobileMenu");
ghs__("#mobile-menu").setAttribute("data", "0");
} else {
ghs__("#menu").style.display = "block";
// ghs__("#menu").classList.remove("mobileMenu");
ghs__("#mobile-menu").setAttribute("data", "1");
}
}







function Addstudent() {
var select = ghs__("#select_bank");
//var Selectvalue = select.value;
var group = select.options[select.selectedIndex].text;
var student_name = __ghs("#student_name").value;
var optional_sub = __ghs("#optional_sub").value;
var religion = __ghs("#religion").value;
var roll = __ghs("#roll_number").value;
var registration = __ghs("#reg_number").value;
var password = __ghs("#password").value;
/*
   *
   * Checking Valuess
   *
   */
if (group === "Chose A Group") {
__ghs("#message").classList.add("error");
__ghs("#message").style.display = "block";
__ghs("#message").textContent = "Select a group please!";
} else if (student_name === "") {
__ghs("#message").classList.add("error");
__ghs("#message").style.display = "block";
__ghs("#message").textContent = "Enter Student Name!";
} else if (roll === "") {
__ghs("#message").classList.add("error");
__ghs("#message").style.display = "block";
__ghs("#message").textContent = "Enter Student Roll !";
} else if (registration === "") {
__ghs("#message").classList.add("error");
__ghs("#message").style.display = "block";
__ghs("#message").textContent = "Enter Registration Please";
} else if (password === "") {
__ghs("#message").classList.add("error");
__ghs("#message").style.display = "block";
__ghs("#message").textContent = "Please Set A Password !";
} else {

var formData = new FormData(__ghs("#application_form"));
formData.append("add_student", "Add New Student");
formData.append("group", group);
fetch("./addUser.php", {
method: "POST",
body: formData,
})
.then((res) => {
return res.text();
})
.then((data) => {
if(data==="Inserted"){
  window.location.href = "http://ghs1.ezyro.com/Admin/";
} else {
alert("Something Error");
}
});
/*
*
*
*
var formData = new FormData(__ghs("#application_form"));
formData.append("add_student", "Add New Student");
formData.append("group", group);
fetch("http://ghs1.ezyro.com/API/server/functions/addStudent.php", {
method: "POST",
body: formData,
})
.then((res) => {
return res.json();
})
.then((data) => {
if (data.status) {
window.location.href = "http://ghs1.ezyro.com/Admin/";
} else {
alert("Something Error");
}
});
*
*
*
*/


}
setTimeout(() => {
__ghs("#message").classList.remove("error");
__ghs("#message").textContent = "";
},
3000);
}
</script>
<!--<script src="js/index.js"></script>
-->
</body>
</html>
<?php
} else {
include_once('login.php');
}
?>